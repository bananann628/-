# 🤖 WeChat AI Agent

> 把 DeepSeek 变成微信聊天机器人 — 支持工具调用、联网搜索、图片识别、文件操作、记忆系统

## ✨ 功能

| 能力 | 说明 |
|------|------|
| 💬 智能对话 | DeepSeek V3/V4/R1 多模型自由切换 |
| 🌐 联网搜索 | Chrome 浏览器自动化，国内外网站都能搜 |
| 🖼️ 图片识别 | 收到微信图片自动用千问 VL 识别内容 |
| 📁 文件操作 | 读写文件、创建 Excel/Word、列出目录 |
| 💻 命令执行 | 运行 Python 脚本、Shell 命令 |
| 🧠 记忆系统 | 记住用户偏好，重启不丢失 |
| 📤 发送文件 | AI 生成的文件直接发回微信 |
| 🎬 视频分析 | 提取关键帧逐帧识别 |

## 🏗️ 架构

```
微信 → cc-connect → fake-claude.py → DeepSeek API
                     ├── 图片识别 → Qwen-VL API
                     ├── 联网搜索 → Chrome CDP (puppeteer)
                     └── 记忆系统 → preferences.txt + memory.json
```

## 🚀 快速开始

### 1. 安装依赖

```powershell
# Node.js 22+
# Python 3.12+
# Chrome 浏览器

npm install -g cc-connect@beta puppeteer-core
pip install openpyxl python-docx pillow imageio-ffmpeg

# 安装并配置 web-access skill（可选，增强联网能力）
npx skills add eze-is/web-access@web-access -g -y
```

### 2. 配置 API Key

打开 `fake-claude.py`，填入你的 API Key：

```python
DEEPSEEK_API_KEY = "sk-你的DeepSeek-Key"
QWEN_API_KEY = "sk-你的千问-Key"  # 阿里云百炼，用于图片识别
```

### 3. 扫码登录微信

```powershell
cc-connect weixin setup --project wechat-bot
```

用微信扫描终端显示的二维码。

### 4. 启动机器人

双击 `启动微信机器人.bat`，或者：

```powershell
cc-connect --force
```

## 📁 文件结构

```
wechat-bot/
├── fake-claude.py          # AI 核心（工具调用、记忆、搜索）
├── chrome-browse.js        # Chrome 浏览器自动化脚本
├── claude.cmd              # cc-connect 启动桥接
├── preferences.txt         # 用户偏好（人类可读）
├── memory.json             # 对话历史 + 事实记忆
├── 启动微信机器人.bat       # 一键启动
└── README.md
```

## 🛠️ 可用工具

机器人可以自主选择使用以下工具：

- `web_search` - 用 Chrome 搜索网页
- `bash` - 执行 Shell 命令和 Python 脚本
- `read` / `write` / `list_dir` / `grep` - 文件操作
- `send_to_wechat` - 发送文件/图片到微信
- `ask_model` - 调用更强的模型（deepseek-v4-pro / deepseek-reasoner）
- `remember_preference` / `forget_preferences` - 记忆偏好
- `read_docx` - 读取 Word 文档
- `analyze_video` - 分析视频内容

## 🗣️ 微信聊天命令

| 命令 | 作用 |
|------|------|
| `/reset` | 重置对话历史和偏好 |

## ⚠️ 注意事项

- 需要一台 Windows 电脑保持开机运行
- Chrome 需要保持打开（或开启 CDP 调试端口）
- DeepSeek 和千问 API 都按量计费，日常聊天用 deepseek-chat 很便宜（月均几块钱）
- 微信 iLink 协议仅供个人学习和研究使用

## 📄 License

MIT

## 🙏 致谢

- [cc-connect](https://github.com/chenhg5/cc-connect) - 微信桥接
- [DeepSeek](https://platform.deepseek.com) - AI 模型
- [Qwen-VL](https://dashscope.aliyun.com) - 图片识别
- [web-access](https://github.com/eze-is/web-access) - 浏览器自动化 Skill
